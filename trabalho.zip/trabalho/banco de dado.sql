CREATE DATABASE minha_api_db;
USE minha_api_db;
